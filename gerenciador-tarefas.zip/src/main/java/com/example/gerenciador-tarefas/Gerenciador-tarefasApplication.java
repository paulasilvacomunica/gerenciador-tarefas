package com.example.gerenciador-tarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gerenciador-tarefasApplication {

    public static void main(String[] args) {
        SpringApplication.run(Gerenciador-tarefasApplication.class, args);
    }
}
